Credit to Tikipeter and 123Venom.

not sure what to do with this experiment, *some crew* will just fill a repo with 3 copies using different names and gaudy artwork (like they did with POV / Dradis) without even a hat tip to Tikipeter, 123Venom, kodifitzwell.

there are some default scrapers included and enabled by default.  check out:
Tools > Scrapers Settings.

debrid account required.

for normal use, from the root menu use the context menu to remove the folder containing this README.md.

peace pooks. ✌️
